-- Inserindo dados na tabela Cliente
INSERT INTO Cliente (CPF, Nome, UF, Celular)
VALUES ('111.111.111-11', 'Cliente 1', 'SP', '1111-1111'),
       ('222.222.222-22', 'Cliente 2', 'RJ', '2222-2222'),
       ('333.333.333-33', 'Cliente 3', 'SP', '3333-3333');

-- Inserindo dados na tabela Financiamento
INSERT INTO Financiamento (IdFinanciamento, CPF, TipoFinanciamento, ValorTotal, DataUltimoVencimento)
VALUES (1, '111.111.111-11', 'Tipo A', 5000.00, '2023-12-31'),
       (2, '222.222.222-22', 'Tipo B', 8000.00, '2023-11-30'),
       (3, '333.333.333-33', 'Tipo C', 3000.00, '2023-10-31');

-- Inserindo dados na tabela Parcela
INSERT INTO Parcela (IdParcela, IdFinanciamento, NumeroParcela, ValorParcela, DataVencimento, DataPagamento)
VALUES (1, 1, 1, 1000.00, '2023-08-31', '2023-09-01'),
       (2, 1, 2, 1000.00, '2023-09-30', '2023-09-25'),
       (3, 1, 3, 1000.00, '2023-10-31', NULL),
       (4, 2, 1, 2000.00, '2023-09-30', NULL),
       (5, 2, 2, 2000.00, '2023-10-31', NULL),
       (6, 2, 3, 4000.00, '2023-11-30', NULL),
       (7, 3, 1, 1000.00, '2023-08-31', '2023-08-29'),
       (8, 3, 2, 1000.00, '2023-09-30', '2023-09-30'),
       (9, 3, 3, 1000.00, '2023-10-31', '2023-10-29');

