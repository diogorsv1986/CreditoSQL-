-- Tabela Cliente
CREATE TABLE Cliente (
    CPF VARCHAR(14) PRIMARY KEY,
    Nome VARCHAR(100),
    UF VARCHAR(2),
    Celular VARCHAR(20)
);

-- Tabela Financiamento
CREATE TABLE Financiamento (
    IdFinanciamento INT PRIMARY KEY,
    CPF VARCHAR(14),
    TipoFinanciamento VARCHAR(50),
    ValorTotal DECIMAL(10, 2),
    DataUltimoVencimento DATE,
    FOREIGN KEY (CPF) REFERENCES Cliente(CPF)
);

-- Tabela Parcela
CREATE TABLE Parcela (
    IdParcela INT PRIMARY KEY,
    IdFinanciamento INT,
    NumeroParcela INT,
    ValorParcela DECIMAL(10, 2),
    DataVencimento DATE,
    DataPagamento DATE,
    FOREIGN KEY (IdFinanciamento) REFERENCES Financiamento(IdFinanciamento)
);
