SELECT DISTINCT TOP 4 C.Nome
FROM Cliente C

JOIN Financiamento F ON C.CPF = F.CPF
JOIN Parcela P ON F.IdFinanciamento = P.IdFinanciamento

WHERE P.DataVencimento > GETDATE() AND P.DataPagamento IS NULL;

