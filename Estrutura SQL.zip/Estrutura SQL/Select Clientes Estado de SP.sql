SELECT C.Nome, COUNT(P.IdParcela) AS ParcelasPagas, COUNT(*) AS TotalParcelas
FROM Cliente C

JOIN Financiamento F ON C.CPF = F.CPF
JOIN Parcela P ON F.IdFinanciamento = P.IdFinanciamento

WHERE C.UF = 'SP' AND P.DataPagamento IS NOT NULL

GROUP BY C.Nome

HAVING COUNT(P.IdParcela) / COUNT(*) > 0.6;
